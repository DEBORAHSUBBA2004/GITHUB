<?php
session_start();
include 'db.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    
    // Fetch the user's name and email from the users table
    $stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($userName, $userEmail);
    $stmt->fetch();
    $stmt->close();
    
    // Fetch the profile picture path from the profile_pictures table
    $stmt = $conn->prepare("SELECT profile_picture_path FROM profile_pictures WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($profilePicturePath);
    $stmt->fetch();
    $stmt->close();

    // Set a default profile picture if none is uploaded
    if (empty($profilePicturePath) || !file_exists($profilePicturePath)) {
        $profilePicturePath = 'default-profile.png';
    }
} else {
    // Redirect to login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Handle profile picture upload via AJAX
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['profile-picture']) && isset($_POST['action']) && $_POST['action'] == 'upload-profile-picture') {
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["profile-picture"]["name"]);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a valid image
    if (!empty($_FILES["profile-picture"]["tmp_name"]) && getimagesize($_FILES["profile-picture"]["tmp_name"])) {
        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES["profile-picture"]["tmp_name"], $targetFile)) {
            // Update the profile picture path in the profile_pictures table
            $stmt = $conn->prepare("INSERT INTO profile_pictures (user_id, profile_picture_path) VALUES (?, ?) ON DUPLICATE KEY UPDATE profile_picture_path = ?");
            $stmt->bind_param("iss", $userId, $targetFile, $targetFile);
            $stmt->execute();
            $stmt->close();

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Error uploading profile picture.";
        }
    } else {
        echo "File is not a valid image.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="profile-picture-upload">
                <img id="profile-picture-display" src="<?php echo htmlspecialchars($profilePicturePath); ?>" alt="Profile Picture">
                <form action="dashboard.php" method="post" enctype="multipart/form-data">
                    <label for="file-upload" class="upload-button">
                        <i class="fas fa-upload"></i> Upload Profile Picture
                    </label>
                    <input type="file" name="profile-picture" id="file-upload" accept="image/jpeg, image/png" style="display: none;">
                    <input type="hidden" name="action" value="upload-profile-picture">
                    <input type="submit" value="Submit" class="submit-button">
                </form>
            </div>
            <div class="user-info">
                <p>User ID: <span id="user-id"><?php echo htmlspecialchars($userId); ?></span></p>
                <p>Username: <span id="username"><?php echo htmlspecialchars($userName); ?></span></p>
                <p>Email: <span id="user-email"><?php echo htmlspecialchars($userEmail); ?></span></p>
            </div>
            <button id="logout-button" onclick="window.location.href='logout.php'">Logout</button>
        </div>
        <div class="body">
            <h1>Welcome, <?php echo htmlspecialchars($userName); ?>!</h1>
            <div class="about-me">
                <h2>Here's More About Me</h2>
                <div class="about-me-content">
                    <p id="about-me-description">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <a href="index.html">Learn More</a>
                    </p>
                    <img src="de.jpeg" alt="Owner's Image" id="owner-image">
                </div>
            </div>
            <div class="social-links">
                <a href="https://github.com/owner" target="_blank"><i class="fab fa-github"></i></a>
                <a href="https://linkedin.com/in/owner" target="_blank"><i class="fab fa-linkedin"></i></a>
                <a href="https://instagram.com/owner" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</body>
</html>
